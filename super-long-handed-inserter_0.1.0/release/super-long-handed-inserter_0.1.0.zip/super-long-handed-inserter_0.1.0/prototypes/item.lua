data:extend({
 {
    type = "item",
    name = "super-long-handed-inserter",
    icon = "__super-long-handed-inserter__/graphics/icons/super-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "inserter",
    order = "c[super-long-handed-inserter]",
    place_result = "super-long-handed-inserter",
    stack_size = 50
  }
})