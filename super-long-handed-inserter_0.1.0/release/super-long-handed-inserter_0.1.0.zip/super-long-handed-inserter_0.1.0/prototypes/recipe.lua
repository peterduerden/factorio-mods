data:extend({
  {
    type = "recipe",
    name = "super-long-handed-inserter",
    enabled = false,
    ingredients =
    {
      {"electronic-circuit", 2},
      {"iron-gear-wheel", 2},
      {"iron-plate", 2},
      {"long-handed-inserter", 1}
    },
    result = "super-long-handed-inserter"
  }
})